import Foundation
//2. დაწერეთ ფუნქცია რომელიც დააჯამებს ციფრებს ორ რიცსხვს შორის.
//   მაგალითად გადმოგვეცემა 19 და 22. მათ შორის ციფრების ჯამი იქნება :
//   // 19, 20, 21, 22
//   // (1 + 9) + (2 + 0) + (2 + 1) + (2 + 2) = 19
//
//   func sumOfDigits(start: Int, end: Int) -> Int {
//       // Your code goes here
//   }
//
//   sumOfDigits(7, 8) ➞ 15
//   sumOfDigits(17, 20) ➞ 29
//   sumOfDigits(10, 12) ➞ 6

func sumOfDigits(start: Int, end: Int) -> Int {
    var digitArray = [Int]()
    for num in start...end{
        if num < 10 {
            digitArray.append(num)
        }
        else {
            let numberString = String(num)
            for digit in numberString {
                if let digitalValue = Int(String(digit)) {
                    digitArray.append(digitalValue)
                }
            }
            
        }
    }
    return digitArray.reduce(0, +)
}


//ამოხსნის მეორე ვარიანტი
func sumOfDigits2(start: Int, end: Int) -> Int {
    var digitArray = [Int]()
    var abs = 0
    var remainder = 0
    for num in start...end{
        if num < 10 {
            digitArray.append(num)
        }
        else {
            abs = Int(num / 10)
            remainder = num % 10
            digitArray.append(abs)
            digitArray.append(remainder)
            
        }
    }
    return digitArray.reduce(0, +)
}


sumOfDigits(start: 7, end: 8)
sumOfDigits(start: 17, end: 20)
sumOfDigits2(start: 7, end: 8)
sumOfDigits2(start: 17, end: 20)
