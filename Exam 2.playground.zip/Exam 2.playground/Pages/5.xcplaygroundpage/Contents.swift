import Foundation

//გადმოგეცემათ მთელი რიცხვი N. დაწერეთ ფუნქცია რომელიც დაითვლის რამდენი 0ით ბოლოვდება N! (ფაქტორიალი)
//     შენიშვნა 1000! შედგება 2568 სიმბოლოსაგან.
//
//     func zeros(N: Int) -> Int {
//         // Your code goes here
//     }
//
//     example:
//     zeros(N: 7) ➞ 1
//     zeros(N: 12) ➞ 2
//     zeros(N: 490) ➞ 120

func zeros(N: Int) -> Int {
    var count = 0
    var power = 5
    if N < 0 {
        return -1
    }
    else {
        while N / power >= 1 {
            count += Int(N / power)
            power *= 5
            print(count)
        }
    }
    
    return count
}

print(zeros(N: 7))
print(zeros(N: 12))
print(zeros(N: 490))
print(zeros(N: 28))

