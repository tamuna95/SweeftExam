import Foundation
//
////1. გვაქვს 1,5,10,20 და 50 თეთრიანი მონეტები. დაწერეთ ფუნქცია, რომელსაც გადაეცემა თანხა (თეთრებში) და აბრუნებს მონეტების მინიმალურ რაოდენობას, რომლითაც შეგვიძლია ეს თანხა დავახურდაოთ.
////    func minSplit(amount: Int) -> Int {
////        // Your code goes here
////    }
////
////    Examples:
////    minSplit(9) ➞ 5  //(1, 1, 1, 1, 5)
////    minSplit(26) ➞ 3  //(1, 5, 20)
////    minSplit(172) ➞ 6  //(1, 1, 20, 50, 50, 50)
///
func minSplit(_ amount: Int) -> Int {
    let coinsArray = [1,5,10,20,50]
    var value = amount
    var count = 0
    for coin in coinsArray.reversed(){
        if amount == 0 {
            return 0
        }
        else{
            while value >= coin {
                value -= coin
                count += 1
            }
        }
        
    }
    
    return count
}

print(minSplit(9))
