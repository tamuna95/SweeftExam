//მოცემულია String რომელიც შედგება „(" და „)" ელემენტებისგან. დაწერეთ ფუნქცია რომელიც აბრუნებს ფრჩხილები არის თუ არა მათემატიკურად სწორად დასმული.
//
//    func isProperly(sequence: String) -> Bool {
//        // Your code goes here
//    }
//
//    Examples:
//    isProperly(sequence: "(()())") ➞ true
//    isProperly(sequence: ")(()") ➞ false
//    isProperly(sequence: "(()())(") ➞ false

func isProperly(sequence: String) -> Bool {
    var value = 0
    for char in sequence {
        if char == "(" {
            value += 1
        } else if char == ")" {
            value -= 1
            if value < 0 {
                return false
            }
        }
    }
    return value == 0
    
}


print(isProperly(sequence: "(()())"))
print(isProperly(sequence: ")(()"))
print(isProperly(sequence: "(()())("))

